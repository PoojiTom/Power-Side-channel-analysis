# Script to clean up temporary files created from previous simulation
echo "Cleaning temporary files created from previous simulations"
rm -rf vcd/*
rm -rf modules/*
rm -rf pkl/*
rm txtfile
rm dumpfile
rm sigArray.pkl
